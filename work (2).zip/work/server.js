
const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 8000;

// Middleware
app.use(cors());
app.use(express.json());

// In-memory storage
let users = [];
let records = [];

// Register Route
app.post('/api/auth/register', (req, res) => {
  const { name, email, password, role, specialization, license, experience } = req.body;
  
  // Check if user already exists
  const existingUser = users.find(u => u.email === email);
  if (existingUser) {
    return res.status(400).json({ msg: 'User already exists' });
  }
  
  // Create new user
  const newUser = {
    id: users.length + 1,
    name,
    email,
    password, // In production, hash this!
    role,
    specialization: role === 'doctor' ? specialization : null,
    license: role === 'doctor' ? license : null,
    experience: role === 'doctor' ? experience : null
  };
  
  users.push(newUser);
  
  res.json({ 
    msg: 'Registration successful!',
    user: { id: newUser.id, name: newUser.name, email: newUser.email, role: newUser.role }
  });
});

// Login Route
app.post('/api/auth/login', (req, res) => {
  const { email, password, role } = req.body;
  
  const user = users.find(u => u.email === email && u.password === password && u.role === role);
  
  if (!user) {
    return res.status(400).json({ msg: 'Invalid credentials' });
  }
  
  res.json({ 
    msg: 'Login successful!',
    user: { id: user.id, name: user.name, email: user.email, role: user.role }
  });
});

// Get all users (for testing)
app.get('/api/users', (req, res) => {
  res.json(users);
});

// Add health record
app.post('/api/records', (req, res) => {
  const { userId, title, description, recordType } = req.body;
  
  const newRecord = {
    id: records.length + 1,
    userId,
    title,
    description,
    recordType,
    createdAt: new Date()
  };
  
  records.push(newRecord);
  res.json({ msg: 'Record added successfully!', record: newRecord });
});

// Get user records
app.get('/api/records/:userId', (req, res) => {
  const userRecords = records.filter(r => r.userId == req.params.userId);
  res.json(userRecords);
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});